package com.boatsafari.trip.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ObserverConfig {

    @Bean
    public ApplicationConfig applicationConfig() {
        // This ensures the singleton is created when Spring starts
        return ApplicationConfig.getInstance();
    }
}