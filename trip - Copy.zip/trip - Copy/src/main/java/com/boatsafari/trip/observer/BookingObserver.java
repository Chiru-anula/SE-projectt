package com.boatsafari.trip.observer;

import com.boatsafari.trip.model.Booking;

public interface BookingObserver {
    void update(Booking booking, String eventType);
}