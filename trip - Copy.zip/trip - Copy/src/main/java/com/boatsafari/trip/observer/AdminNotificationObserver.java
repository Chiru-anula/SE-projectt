package com.boatsafari.trip.observer;

import com.boatsafari.trip.model.Booking;
import org.springframework.stereotype.Component;

@Component
public class AdminNotificationObserver implements BookingObserver {

    @Override
    public void update(Booking booking, String eventType) {
        System.out.println("=== ADMIN NOTIFICATION ===");
        System.out.println("Event: " + eventType);
        System.out.println("Booking ID: " + booking.getId());
        System.out.println("Customer: " + booking.getCustomerName());
        System.out.println("Trip: " + booking.getTrip().getTripName());
        System.out.println("Amount: $" + booking.getTotalPrice());
        System.out.println("===========================");
    }
}