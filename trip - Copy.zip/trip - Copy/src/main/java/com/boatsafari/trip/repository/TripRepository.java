package com.boatsafari.trip.repository;

import com.boatsafari.trip.model.Trip;
import com.boatsafari.trip.model.TripStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface TripRepository extends JpaRepository<Trip, Long> {
    List<Trip> findByStatus(TripStatus status);
    List<Trip> findByTripDateAfter(LocalDate date);
    List<Trip> findByAvailableSlotsGreaterThan(Integer slots);
}