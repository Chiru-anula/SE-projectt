package com.boatsafari.trip.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "trips")
public class Trip {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "trip_name", nullable = false)
    private String tripName;

    @Column(name = "boat_type", nullable = false)
    private String boatType;

    @Column(nullable = false)
    private String destination;

    @Column(name = "duration_hours", nullable = false)
    private Integer durationHours;

    @Column(name = "price_per_person", nullable = false, precision = 10, scale = 2)
    private BigDecimal pricePerPerson;

    @Column(name = "available_slots", nullable = false)
    private Integer availableSlots;

    @Column(name = "trip_date", nullable = false)
    private LocalDate tripDate;

    @Column(name = "trip_time", nullable = false)
    private LocalTime tripTime;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Enumerated(EnumType.STRING)
    private TripStatus status = TripStatus.ACTIVE;

    @Column(name = "created_at")
    private java.time.LocalDateTime createdAt;

    // Constructors
    public Trip() {
        this.createdAt = java.time.LocalDateTime.now();
    }

    public Trip(String tripName, String boatType, String destination, Integer durationHours,
                BigDecimal pricePerPerson, Integer availableSlots, LocalDate tripDate,
                LocalTime tripTime, String description) {
        this();
        this.tripName = tripName;
        this.boatType = boatType;
        this.destination = destination;
        this.durationHours = durationHours;
        this.pricePerPerson = pricePerPerson;
        this.availableSlots = availableSlots;
        this.tripDate = tripDate;
        this.tripTime = tripTime;
        this.description = description;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTripName() { return tripName; }
    public void setTripName(String tripName) { this.tripName = tripName; }

    public String getBoatType() { return boatType; }
    public void setBoatType(String boatType) { this.boatType = boatType; }

    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }

    public Integer getDurationHours() { return durationHours; }
    public void setDurationHours(Integer durationHours) { this.durationHours = durationHours; }

    public BigDecimal getPricePerPerson() { return pricePerPerson; }
    public void setPricePerPerson(BigDecimal pricePerPerson) { this.pricePerPerson = pricePerPerson; }

    public Integer getAvailableSlots() { return availableSlots; }
    public void setAvailableSlots(Integer availableSlots) { this.availableSlots = availableSlots; }

    public LocalDate getTripDate() { return tripDate; }
    public void setTripDate(LocalDate tripDate) { this.tripDate = tripDate; }

    public LocalTime getTripTime() { return tripTime; }
    public void setTripTime(LocalTime tripTime) { this.tripTime = tripTime; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public TripStatus getStatus() { return status; }
    public void setStatus(TripStatus status) { this.status = status; }

    public java.time.LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(java.time.LocalDateTime createdAt) { this.createdAt = createdAt; }
}

