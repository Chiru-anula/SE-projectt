package com.boatsafari.trip.controller;

import com.boatsafari.trip.config.ApplicationConfig;
import com.boatsafari.trip.model.Booking;
import com.boatsafari.trip.model.BookingStatus;
import com.boatsafari.trip.model.Trip;
import com.boatsafari.trip.observer.AdminNotificationObserver;
import com.boatsafari.trip.observer.EmailNotificationObserver;
import com.boatsafari.trip.service.BookingService;
import com.boatsafari.trip.service.TripService;
import com.boatsafari.trip.strategy.ExportContext;
import com.boatsafari.trip.strategy.ExportStrategy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import jakarta.annotation.PostConstruct;
import java.math.BigDecimal;
import java.util.Optional;

@Controller
public class MainController {

    @Autowired
    private TripService tripService;

    @Autowired
    private BookingService bookingService;

    @Autowired
    private EmailNotificationObserver emailObserver;

    @Autowired
    private AdminNotificationObserver adminObserver;

    @Autowired
    private ExportContext exportContext;

    // Initialize observers
    @PostConstruct
    public void init() {
        bookingService.registerObserver(emailObserver);
        bookingService.registerObserver(adminObserver);
        System.out.println("Observers registered successfully");
    }

    // Home page with Singleton usage
    @GetMapping("/")
    public String home(Model model) {
        ApplicationConfig config = ApplicationConfig.getInstance();
        model.addAttribute("appInfo", config.getAppInfo());
        model.addAttribute("maintenanceMode", config.isMaintenanceMode());
        return "home";
    }

    @GetMapping("/home")
    public String homePage(Model model) {
        ApplicationConfig config = ApplicationConfig.getInstance();
        model.addAttribute("appInfo", config.getAppInfo());
        return "home";
    }

    // NEW PAGES - ADD THESE ROUTES
    @GetMapping("/tours")
    public String tours(Model model) {
        ApplicationConfig config = ApplicationConfig.getInstance();
        model.addAttribute("appInfo", config.getAppInfo());
        return "tours"; // tours.html
    }

    @GetMapping("/destinations")
    public String destinations(Model model) {
        ApplicationConfig config = ApplicationConfig.getInstance();
        model.addAttribute("appInfo", config.getAppInfo());
        return "destinations"; // destinations.html
    }

    @GetMapping("/about")
    public String about(Model model) {
        ApplicationConfig config = ApplicationConfig.getInstance();
        model.addAttribute("appInfo", config.getAppInfo());
        return "about"; // about.html
    }

    @GetMapping("/contact")
    public String contact(Model model) {
        ApplicationConfig config = ApplicationConfig.getInstance();
        model.addAttribute("appInfo", config.getAppInfo());
        return "contact"; // contact.html
    }

    // REMOVE THIS LOGIN METHOD - KEEP ONLY IN LOGINCONTROLLER
    // @GetMapping("/login")
    // public String login(Model model) {
    //     ApplicationConfig config = ApplicationConfig.getInstance();
    //     model.addAttribute("appInfo", config.getAppInfo());
    //     return "login"; // login.html
    // }

    // EXISTING ROUTES - KEEP THESE AS THEY ARE
    // Public trip listing
    @GetMapping("/trips")
    public String getAllTrips(Model model) {
        model.addAttribute("trips", tripService.getAllTrips());
        return "trips";
    }

    // Individual trip details
    @GetMapping("/trips/{id}")
    public String getTripById(@PathVariable Long id, Model model) {
        Optional<Trip> trip = tripService.getTripById(id);
        if (trip.isPresent()) {
            model.addAttribute("trip", trip.get());
            return "trip-details";
        }
        return "redirect:/trips";
    }

    // Booking form
    @GetMapping("/bookings/create")
    public String createBookingForm(@RequestParam Long tripId, Model model) {
        Optional<Trip> trip = tripService.getTripById(tripId);
        if (trip.isPresent() && trip.get().getAvailableSlots() > 0) {
            Booking booking = new Booking();
            booking.setTrip(trip.get());
            model.addAttribute("booking", booking);
            return "booking-form";
        }
        return "redirect:/trips";
    }

    // Save booking
    @PostMapping("/bookings/save")
    public String saveBooking(@ModelAttribute Booking booking) {
        try {
            // Calculate total price
            Trip trip = booking.getTrip();
            BigDecimal totalPrice = trip.getPricePerPerson().multiply(BigDecimal.valueOf(booking.getNumberOfPeople()));
            booking.setTotalPrice(totalPrice);

            bookingService.createBooking(booking);
            return "redirect:/bookings/confirmation?bookingId=" + booking.getId();
        } catch (Exception e) {
            return "redirect:/bookings/create?tripId=" + booking.getTrip().getId() + "&error=true";
        }
    }

    // Booking confirmation
    @GetMapping("/bookings/confirmation")
    public String bookingConfirmation(@RequestParam Long bookingId, Model model) {
        Optional<Booking> booking = bookingService.getBookingById(bookingId);
        if (booking.isPresent()) {
            model.addAttribute("booking", booking.get());
            return "booking-confirmation";
        }
        return "redirect:/trips";
    }

    // ADMIN ROUTES - UPDATED WITH ALL PATTERNS
    @GetMapping("/admin/dashboard")
    public String dashboard(Model model) {
        ApplicationConfig config = ApplicationConfig.getInstance();

        model.addAttribute("tripsCount", tripService.getAllTrips().size());
        model.addAttribute("bookingsCount", bookingService.getAllBookings().size());
        model.addAttribute("exportFormats", bookingService.getSupportedExportFormats());
        model.addAttribute("appInfo", config.getAppInfo());
        model.addAttribute("maintenanceMode", config.isMaintenanceMode());

        return "admin/dashboard";
    }

    // Trip Management
    @GetMapping("/admin/trips")
    public String trips(Model model) {
        model.addAttribute("trips", tripService.getAllTrips());
        model.addAttribute("exportFormats", bookingService.getSupportedExportFormats());
        return "admin/trips";
    }

    @GetMapping("/admin/trips/create")
    public String createTripForm(Model model) {
        model.addAttribute("trip", new Trip());
        return "admin/create-trip";
    }

    @PostMapping("/admin/trips/save")
    public String saveTrip(@ModelAttribute Trip trip) {
        tripService.saveTrip(trip);
        return "redirect:/admin/trips";
    }

    @GetMapping("/admin/trips/edit/{id}")
    public String editTripForm(@PathVariable Long id, Model model) {
        Optional<Trip> trip = tripService.getTripById(id);
        if (trip.isPresent()) {
            model.addAttribute("trip", trip.get());
            return "admin/edit-trip";
        }
        return "redirect:/admin/trips";
    }

    @GetMapping("/admin/trips/delete/{id}")
    public String deleteTrip(@PathVariable Long id) {
        tripService.deleteTrip(id);
        return "redirect:/admin/trips";
    }

    // Booking Management
    @GetMapping("/admin/bookings")
    public String bookings(Model model) {
        model.addAttribute("bookings", bookingService.getAllBookings());
        model.addAttribute("exportFormats", bookingService.getSupportedExportFormats());
        return "admin/bookings";
    }

    // Updated export endpoint using Strategy pattern
    @GetMapping("/admin/bookings/export")
    public ResponseEntity<byte[]> exportBookings(@RequestParam String format) {
        try {
            ExportStrategy strategy = exportContext.getStrategy(format);
            if (strategy == null) {
                throw new IllegalArgumentException("Unsupported format: " + format);
            }

            byte[] exportData = bookingService.exportBookings(format);

            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(strategy.getContentType()))
                    .header(HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=\"" + strategy.getFileName() + "\"")
                    .body(exportData);

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(("Export failed: " + e.getMessage()).getBytes());
        }
    }

    // Admin maintenance mode toggle (Singleton usage)
    @GetMapping("/admin/toggle-maintenance")
    public String toggleMaintenanceMode() {
        ApplicationConfig config = ApplicationConfig.getInstance();
        config.setMaintenanceMode(!config.isMaintenanceMode());
        return "redirect:/admin/dashboard";
    }

    @GetMapping("/admin/bookings/confirm/{id}")
    public String confirmBooking(@PathVariable Long id) {
        bookingService.updateBookingStatus(id, BookingStatus.CONFIRMED);
        return "redirect:/admin/bookings";
    }

    @GetMapping("/admin/bookings/cancel/{id}")
    public String cancelBooking(@PathVariable Long id) {
        bookingService.updateBookingStatus(id, BookingStatus.CANCELLED);
        return "redirect:/admin/bookings";
    }

    @GetMapping("/admin/bookings/delete/{id}")
    public String deleteBooking(@PathVariable Long id) {
        bookingService.deleteBooking(id);
        return "redirect:/admin/bookings";
    }
}