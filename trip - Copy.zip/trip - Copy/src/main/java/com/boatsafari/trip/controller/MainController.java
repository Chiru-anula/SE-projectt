package com.boatsafari.trip.controller;

import com.boatsafari.trip.model.Booking;
import com.boatsafari.trip.model.BookingStatus;
import com.boatsafari.trip.model.Trip;
import com.boatsafari.trip.service.BookingService;
import com.boatsafari.trip.service.TripService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Optional;

@Controller
public class MainController {

    @Autowired
    private TripService tripService;

    @Autowired
    private BookingService bookingService;

    // ONLY MainController handles the home page
    @GetMapping("/")
    public String home() {
        return "home";
    }

    @GetMapping("/home")
    public String homePage() {
        return "home";
    }

    // Public trip listing
    @GetMapping("/trips")
    public String getAllTrips(Model model) {
        model.addAttribute("trips", tripService.getAllTrips());
        return "trips";
    }

    // Individual trip details
    @GetMapping("/trips/{id}")
    public String getTripById(@PathVariable Long id, Model model) {
        Optional<Trip> trip = tripService.getTripById(id);
        if (trip.isPresent()) {
            model.addAttribute("trip", trip.get());
            return "trip-details";
        }
        return "redirect:/trips";
    }

    // Booking form
    @GetMapping("/bookings/create")
    public String createBookingForm(@RequestParam Long tripId, Model model) {
        Optional<Trip> trip = tripService.getTripById(tripId);
        if (trip.isPresent() && trip.get().getAvailableSlots() > 0) {
            Booking booking = new Booking();
            booking.setTrip(trip.get());
            model.addAttribute("booking", booking);
            return "booking-form";
        }
        return "redirect:/trips";
    }

    // Save booking
    @PostMapping("/bookings/save")
    public String saveBooking(@ModelAttribute Booking booking) {
        try {
            // Calculate total price
            Trip trip = booking.getTrip();
            BigDecimal totalPrice = trip.getPricePerPerson().multiply(BigDecimal.valueOf(booking.getNumberOfPeople()));
            booking.setTotalPrice(totalPrice);

            bookingService.createBooking(booking);
            return "redirect:/bookings/confirmation?bookingId=" + booking.getId();
        } catch (Exception e) {
            return "redirect:/bookings/create?tripId=" + booking.getTrip().getId() + "&error=true";
        }
    }

    // Booking confirmation
    @GetMapping("/bookings/confirmation")
    public String bookingConfirmation(@RequestParam Long bookingId, Model model) {
        Optional<Booking> booking = bookingService.getBookingById(bookingId);
        if (booking.isPresent()) {
            model.addAttribute("booking", booking.get());
            return "booking-confirmation";
        }
        return "redirect:/trips";
    }

    // ADMIN ROUTES
    @GetMapping("/admin/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("tripsCount", tripService.getAllTrips().size());
        model.addAttribute("bookingsCount", bookingService.getAllBookings().size());
        return "admin/dashboard";
    }

    // Trip Management
    @GetMapping("/admin/trips")
    public String trips(Model model) {
        model.addAttribute("trips", tripService.getAllTrips());
        return "admin/trips";
    }

    @GetMapping("/admin/trips/create")
    public String createTripForm(Model model) {
        model.addAttribute("trip", new Trip());
        return "admin/create-trip";
    }

    @PostMapping("/admin/trips/save")
    public String saveTrip(@ModelAttribute Trip trip) {
        tripService.saveTrip(trip);
        return "redirect:/admin/trips";
    }

    @GetMapping("/admin/trips/edit/{id}")
    public String editTripForm(@PathVariable Long id, Model model) {
        Optional<Trip> trip = tripService.getTripById(id);
        if (trip.isPresent()) {
            model.addAttribute("trip", trip.get());
            return "admin/edit-trip";
        }
        return "redirect:/admin/trips";
    }

    @GetMapping("/admin/trips/delete/{id}")
    public String deleteTrip(@PathVariable Long id) {
        tripService.deleteTrip(id);
        return "redirect:/admin/trips";
    }

    // Booking Management
    @GetMapping("/admin/bookings")
    public String bookings(Model model) {
        model.addAttribute("bookings", bookingService.getAllBookings());
        return "admin/bookings";
    }

    @GetMapping("/admin/bookings/confirm/{id}")
    public String confirmBooking(@PathVariable Long id) {
        bookingService.updateBookingStatus(id, BookingStatus.CONFIRMED);
        return "redirect:/admin/bookings";
    }

    @GetMapping("/admin/bookings/cancel/{id}")
    public String cancelBooking(@PathVariable Long id) {
        bookingService.updateBookingStatus(id, BookingStatus.CANCELLED);
        return "redirect:/admin/bookings";
    }

    @GetMapping("/admin/bookings/delete/{id}")
    public String deleteBooking(@PathVariable Long id) {
        bookingService.deleteBooking(id);
        return "redirect:/admin/bookings";
    }
}