package com.boatsafari.trip.model;

public enum BookingStatus {
    PENDING, CONFIRMED, CANCELLED
}
