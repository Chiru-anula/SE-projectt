package com.boatsafari.trip.controller;

import com.boatsafari.trip.config.ApplicationConfig;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

    @GetMapping("/api/test-singleton")
    public String testSingleton() {
        ApplicationConfig config1 = ApplicationConfig.getInstance();
        ApplicationConfig config2 = ApplicationConfig.getInstance();

        return "Singleton Test: " + (config1 == config2) +
                "\nApp Info: " + config1.getAppInfo();
    }
}