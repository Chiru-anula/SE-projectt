package com.boatsafari.trip.repository;

import com.boatsafari.trip.model.Booking;
import com.boatsafari.trip.model.BookingStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByCustomerEmail(String customerEmail);
    List<Booking> findByStatus(BookingStatus status);
    List<Booking> findByTripId(Long tripId);
}