package com.boatsafari.trip.strategy;

import com.boatsafari.trip.model.Booking;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;

public class JsonExportStrategy implements ExportStrategy {

    @Override
    public byte[] export(List<Booking> bookings) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.writeValueAsBytes(bookings);
        } catch (Exception e) {
            throw new RuntimeException("Failed to export to JSON", e);
        }
    }

    @Override
    public String getContentType() {
        return "application/json";
    }

    @Override
    public String getFileName() {
        return "bookings.json";
    }
}