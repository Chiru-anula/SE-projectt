package com.boatsafari.trip.strategy;

import com.boatsafari.trip.model.Booking;

import java.util.List;

public class CsvExportStrategy implements ExportStrategy {

    @Override
    public byte[] export(List<Booking> bookings) {
        StringBuilder sb = new StringBuilder();
        sb.append("ID,Customer Name,Email,Phone,Number of People,Total Price,Status,Trip Name\n");
        for (Booking b : bookings) {
            sb.append(b.getId()).append(",")
                    .append(b.getCustomerName()).append(",")
                    .append(b.getCustomerEmail()).append(",")
                    .append(b.getCustomerPhone()).append(",")
                    .append(b.getNumberOfPeople()).append(",")
                    .append(b.getTotalPrice()).append(",")
                    .append(b.getStatus()).append(",")
                    .append(b.getTrip().getTripName()).append("\n");
        }
        return sb.toString().getBytes();
    }

    @Override
    public String getContentType() {
        return "text/csv";
    }

    @Override
    public String getFileName() {
        return "bookings.csv";
    }
}