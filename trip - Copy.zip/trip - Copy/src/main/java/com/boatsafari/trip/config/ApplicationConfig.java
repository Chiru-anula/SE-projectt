package com.boatsafari.trip.config;

import org.springframework.stereotype.Component;

@Component
public class ApplicationConfig {
    // GoF Singleton implementation
    private static ApplicationConfig instance;

    private String appName = "Boat Safari Trip Booking";
    private String version = "1.0.0";
    private boolean maintenanceMode = false;

    // Private constructor for GoF Singleton
    private ApplicationConfig() {
        // Initialize configuration
        System.out.println("ApplicationConfig Singleton created");
    }

    // Static method to get the singleton instance
    public static ApplicationConfig getInstance() {
        if (instance == null) {
            synchronized (ApplicationConfig.class) {
                if (instance == null) {
                    instance = new ApplicationConfig();
                }
            }
        }
        return instance;
    }

    // Configuration methods
    public String getAppName() {
        return appName;
    }

    public String getVersion() {
        return version;
    }

    public boolean isMaintenanceMode() {
        return maintenanceMode;
    }

    public void setMaintenanceMode(boolean maintenanceMode) {
        this.maintenanceMode = maintenanceMode;
    }

    public String getAppInfo() {
        return appName + " v" + version;
    }
}