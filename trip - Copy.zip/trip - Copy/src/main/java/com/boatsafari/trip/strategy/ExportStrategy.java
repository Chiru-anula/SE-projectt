package com.boatsafari.trip.strategy;

import com.boatsafari.trip.model.Booking;

import java.util.List;

public interface ExportStrategy {
    byte[] export(List<Booking> bookings);
    String getContentType();
    String getFileName();
}