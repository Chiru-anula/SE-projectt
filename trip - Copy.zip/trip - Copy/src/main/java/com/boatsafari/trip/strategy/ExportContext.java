package com.boatsafari.trip.strategy;

import com.boatsafari.trip.model.Booking;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class ExportContext {

    private final Map<String, ExportStrategy> strategies = new HashMap<>();

    public ExportContext() {
        strategies.put("csv", new CsvExportStrategy());
        strategies.put("json", new JsonExportStrategy());
        // Add more strategies here if needed, e.g., PDF
    }

    public ExportStrategy getStrategy(String format) {
        return strategies.get(format.toLowerCase());
    }

    public byte[] executeExport(String format, List<Booking> data) {
        ExportStrategy strategy = getStrategy(format);
        if (strategy == null) {
            throw new IllegalArgumentException("Unsupported export format: " + format);
        }
        return strategy.export(data);
    }

    public List<String> getSupportedFormats() {
        return new ArrayList<>(strategies.keySet());
    }
}