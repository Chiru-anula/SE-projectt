package com.boatsafari.trip.observer;

import com.boatsafari.trip.model.Booking;

public interface BookingSubject {
    void registerObserver(BookingObserver observer);
    void removeObserver(BookingObserver observer);
    void notifyObservers(Booking booking, String eventType);
}