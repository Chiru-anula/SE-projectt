package com.boatsafari.trip.model;

public enum TripStatus {
    ACTIVE, INACTIVE
}
