package com.boatsafari.trip.observer;

import com.boatsafari.trip.model.Booking;
import org.springframework.stereotype.Component;

@Component
public class EmailNotificationObserver implements BookingObserver {

    @Override
    public void update(Booking booking, String eventType) {
        switch (eventType) {
            case "CREATED":
                sendBookingConfirmationEmail(booking);
                break;
            case "CONFIRMED":
                sendBookingConfirmedEmail(booking);
                break;
            case "CANCELLED":
                sendBookingCancelledEmail(booking);
                break;
        }
    }

    private void sendBookingConfirmationEmail(Booking booking) {
        System.out.println("=== EMAIL NOTIFICATION ===");
        System.out.println("To: " + booking.getCustomerEmail());
        System.out.println("Subject: Booking Confirmation - Booking #" + booking.getId());
        System.out.println("Message: Dear " + booking.getCustomerName() + ", your booking for " +
                booking.getTrip().getTripName() + " has been received.");
        System.out.println("Total: $" + booking.getTotalPrice());
        System.out.println("===========================");
    }

    private void sendBookingConfirmedEmail(Booking booking) {
        System.out.println("=== EMAIL NOTIFICATION ===");
        System.out.println("To: " + booking.getCustomerEmail());
        System.out.println("Subject: Booking Confirmed - Booking #" + booking.getId());
        System.out.println("Message: Great news! Your booking has been confirmed.");
        System.out.println("===========================");
    }

    private void sendBookingCancelledEmail(Booking booking) {
        System.out.println("=== EMAIL NOTIFICATION ===");
        System.out.println("To: " + booking.getCustomerEmail());
        System.out.println("Subject: Booking Cancelled - Booking #" + booking.getId());
        System.out.println("Message: Your booking has been cancelled.");
        System.out.println("===========================");
    }
}