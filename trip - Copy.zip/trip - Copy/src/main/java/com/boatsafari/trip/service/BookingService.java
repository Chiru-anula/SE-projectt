package com.boatsafari.trip.service;

import com.boatsafari.trip.model.Booking;
import com.boatsafari.trip.model.BookingStatus;
import com.boatsafari.trip.model.Trip;
import com.boatsafari.trip.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private TripService tripService;

    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    public Optional<Booking> getBookingById(Long id) {
        return bookingRepository.findById(id);
    }

    @Transactional
    public Booking createBooking(Booking booking) {
        // Update available slots in the trip
        Trip trip = booking.getTrip();
        if (trip.getAvailableSlots() >= booking.getNumberOfPeople()) {
            trip.setAvailableSlots(trip.getAvailableSlots() - booking.getNumberOfPeople());
            tripService.saveTrip(trip); // Use saveTrip instead of updateTrip
            return bookingRepository.save(booking);
        } else {
            throw new IllegalArgumentException("Not enough available slots");
        }
    }

    public Booking updateBookingStatus(Long id, BookingStatus status) {
        Optional<Booking> bookingOpt = bookingRepository.findById(id);
        if (bookingOpt.isPresent()) {
            Booking booking = bookingOpt.get();
            booking.setStatus(status);
            return bookingRepository.save(booking);
        }
        throw new IllegalArgumentException("Booking not found");
    }

    public void deleteBooking(Long id) {
        bookingRepository.deleteById(id);
    }
}