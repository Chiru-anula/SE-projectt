package com.boatsafari.trip.service;

import com.boatsafari.trip.model.Booking;
import com.boatsafari.trip.model.BookingStatus;
import com.boatsafari.trip.observer.BookingObserver;
import com.boatsafari.trip.observer.BookingSubject;
import com.boatsafari.trip.repository.BookingRepository;
import com.boatsafari.trip.strategy.ExportContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class BookingService implements BookingSubject {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private ExportContext exportContext;

    // Observer pattern implementation
    private List<BookingObserver> observers = new ArrayList<>();

    @Override
    public void registerObserver(BookingObserver observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(BookingObserver observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(Booking booking, String eventType) {
        for (BookingObserver observer : observers) {
            observer.update(booking, eventType);
        }
    }

    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    public Optional<Booking> getBookingById(Long id) {
        return bookingRepository.findById(id);
    }

    public Booking createBooking(Booking booking) {
        booking.setStatus(BookingStatus.PENDING);
        Booking savedBooking = bookingRepository.save(booking);

        // Notify observers about new booking
        notifyObservers(savedBooking, "CREATED");
        return savedBooking;
    }

    public void updateBookingStatus(Long id, BookingStatus status) {
        Optional<Booking> bookingOpt = bookingRepository.findById(id);
        if (bookingOpt.isPresent()) {
            Booking booking = bookingOpt.get();
            booking.setStatus(status);
            Booking updatedBooking = bookingRepository.save(booking);

            // Notify observers about status change
            String eventType = status == BookingStatus.CONFIRMED ? "CONFIRMED" : "CANCELLED";
            notifyObservers(updatedBooking, eventType);
        }
    }

    public void deleteBooking(Long id) {
        Optional<Booking> bookingOpt = bookingRepository.findById(id);
        if (bookingOpt.isPresent()) {
            Booking booking = bookingOpt.get();
            bookingRepository.deleteById(id);

            // Notify observers about deletion
            notifyObservers(booking, "DELETED");
        }
    }

    // Export functionality
    public byte[] exportBookings(String format) {
        List<Booking> bookings = getAllBookings();
        return exportContext.executeExport(format, bookings);
    }

    public List<String> getSupportedExportFormats() {
        return exportContext.getSupportedFormats();
    }
}