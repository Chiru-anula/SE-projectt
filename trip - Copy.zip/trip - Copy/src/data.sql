-- Create database
CREATE DATABASE IF NOT EXISTS boatsafari;

-- Use the database
USE boatsafari;

-- Create trips table (for admin to add trip details)
CREATE TABLE trips (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    trip_name VARCHAR(100) NOT NULL,
    boat_type VARCHAR(50) NOT NULL,
    destination VARCHAR(100) NOT NULL,
    duration_hours INT NOT NULL,
    price_per_person DECIMAL(10,2) NOT NULL,
    available_slots INT NOT NULL,
    trip_date DATE NOT NULL,
    trip_time TIME NOT NULL,
    description TEXT,bookings
    status ENUM('ACTIVE', 'INACTIVE') DEFAULT 'ACTIVE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create bookings table (for customers to book trips)
CREATE TABLE bookings (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    trip_id BIGINT,
    customer_name VARCHAR(100) NOT NULL,
    customer_email VARCHAR(100) NOT NULL,
    customer_phone VARCHAR(20),
    number_of_people INT NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('PENDING', 'CONFIRMED', 'CANCELLED') DEFAULT 'PENDING',
    FOREIGN KEY (trip_id) REFERENCES trips(id)
);

-- Insert sample trip data
INSERT INTO trips (trip_name, boat_type, destination, duration_hours, price_per_person, available_slots, trip_date, trip_time, description) VALUES
('Sunset Cruise', 'Luxury Yacht', 'Harbor Bay', 3, 75.00, 20, '2025-10-05', '17:00:00', 'Evening cruise with beautiful sunset views'),
('Fishing Adventure', 'Fishing Boat', 'Deep Sea', 5, 120.00, 8, '2025-10-06', '06:00:00', 'Deep sea fishing experience with equipment provided'),
('Island Hopping', 'Speed Boat', 'Coral Islands', 4, 90.00, 15, '2025-10-07', '09:00:00', 'Visit multiple islands with snorkeling opportunities');

-- Insert sample booking data
INSERT INTO bookings (trip_id, customer_name, customer_email, customer_phone, number_of_people, total_price, status) VALUES
(1, 'John Doe', 'john@email.com', '123-456-7890', 2, 150.00, 'CONFIRMED'),
(1, 'Jane Smith', 'jane@email.com', '123-456-7891', 4, 300.00, 'PENDING'),
(2, 'Mike Johnson', 'mike@email.com', '123-456-7892', 3, 360.00, 'CONFIRMED');